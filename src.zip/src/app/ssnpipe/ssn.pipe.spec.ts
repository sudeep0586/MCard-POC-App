/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SsnPipe } from './ssn.pipe';

describe('SsnPipe', () => {
  it('create an instance', () => {
    const pipe = new SsnPipe();
    expect(pipe).toBeTruthy();
  });
});
