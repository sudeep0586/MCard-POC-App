/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { LimitToDirective } from './limit-to.directive';

describe('LimitToDirective', () => {
  it('should create an instance', () => {
    const directive = new LimitToDirective();
    expect(directive).toBeTruthy();
  });
});
