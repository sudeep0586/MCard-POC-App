// /* tslint:disable:no-unused-variable */

// import { TestBed, async, inject } from '@angular/core/testing';
// import { EmailValidator, PhoneValidator,PasswordValidator,EqualValidator} from './validator.service';

// describe('Service: Validator', () => {
//   beforeEach(() => {
//     TestBed.configureTestingModule({
//       providers: [EmailValidator,PhoneValidator,PasswordValidator,EqualValidator]
//     });
//   });

//   it('should ...', inject([EmailValidator], (service: EmailValidator) => {
//     expect(service).toBeTruthy();
//   }));
//   it('should ...', inject([PhoneValidator], (service: PhoneValidator) => {
//     expect(service).toBeTruthy();
//   }));
//   it('should ...', inject([PasswordValidator], (service: PasswordValidator) => {
//     expect(service).toBeTruthy();
//   }));
//   it('should ...', inject([EqualValidator], (service: EqualValidator) => {
//     expect(service).toBeTruthy();
//   }));
// });
