import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'category-component',
    templateUrl: 'category.component.html',
    styleUrls: ['category.component.css']
})

export class CategoryComponent{
    constructor(){}
}
