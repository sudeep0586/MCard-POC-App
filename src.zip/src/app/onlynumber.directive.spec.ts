import { OnlynumberDirective } from './onlynumber.directive';

describe('OnlynumberDirective', () => {
  it('should create an instance', () => {
    const directive = new OnlynumberDirective();
    expect(directive).toBeTruthy();
  });
});
